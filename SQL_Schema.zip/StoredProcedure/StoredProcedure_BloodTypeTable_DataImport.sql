use groupprojectdb;
SELECT * FROM groupprojectdb.bloodtype;	
DELETE FROM groupprojectdb.bloodtype;

 LOAD DATA INFILE 'C:/DBAS32100_GroupProject/Data/data_bloodtype.csv' 
        INTO TABLE groupprojectdb.bloodtype
        FIELDS TERMINATED BY ','
        LINES TERMINATED BY '\n';       
        
SELECT * FROM groupprojectdb.bloodtype;	