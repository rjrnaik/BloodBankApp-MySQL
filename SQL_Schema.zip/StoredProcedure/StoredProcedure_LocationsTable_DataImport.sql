SELECT * FROM groupprojectdb.location;
use groupprojectdb;

DELIMITER //
CREATE PROCEDURE ImportDataFromTextFile()
BEGIN
    -- Load data from the text file into the target table
    SET @sql = CONCAT(
        "LOAD DATA INFILE 'C:/Users/rjrna/Documents/Spring-Summer 2023/DBAS32100 Database Management/Project/Data/location.txt' 
        INTO TABLE groupprojectdb.location
        FIELDS TERMINATED BY '|'
        LINES TERMINATED BY '\n';"
    );

    -- Execute the dynamic SQL
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END //
DELIMITER ;

CALL ImportDataFromTextFile('C:/Users/rjrna/Documents/Spring-Summer 2023/DBAS32100 Database Management/Project/Data/location.txt', 'location');


