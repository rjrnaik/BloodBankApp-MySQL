USE groupprojectdb;

SELECT * FROM donor;

DELIMITER //
CREATE TRIGGER verify_donorAge_before_insert
BEFORE INSERT
ON donor
FOR EACH ROW
BEGIN
  IF NEW.age < 17 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Insert Operation not performed. Too young to donate blood, must be atleast 17 years old';
  END IF;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER verify_donorAge_before_update
BEFORE UPDATE
ON donor
FOR EACH ROW
BEGIN
  IF NEW.age < 17 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Update Operation not performed. Too young to donate blood, must be atleast 17 years old';
  END IF;
END;
//
DELIMITER ;

INSERT INTO donor VALUES(5, "Raymond", "Jackson", 16,5);

UPDATE donor SET donor.age = 16 WHERE donorId = "2";