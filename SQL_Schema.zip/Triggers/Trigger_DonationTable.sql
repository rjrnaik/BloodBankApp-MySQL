USE groupprojectdb;

SELECT * FROM groupprojectdb.donation;donation

DELIMITER //
CREATE TRIGGER verify_donation_date_before_insert
BEFORE INSERT
ON donation
FOR EACH ROW
BEGIN
  IF NEW.date < NOW() THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Insert operation not completed. Date must be in the future';
  END IF;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER verify_donation_date_before_update
BEFORE UPDATE
ON donation
FOR EACH ROW
BEGIN
  IF NEW.date < NOW() THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Update operation not completed. Date must be in the future';
  END IF;
END;
//
DELIMITER ;

INSERT INTO donation VALUES(5, '2002-08-11', 2,1);
UPDATE donation SET date = '2021-10-01' WHERE donationId = 4;