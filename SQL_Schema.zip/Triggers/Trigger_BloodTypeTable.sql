USE groupprojectdb;

SELECT * FROM bloodtype;

DELIMITER //
CREATE TRIGGER verify_bloodType_before_insert
BEFORE INSERT
ON bloodtype
FOR EACH ROW
BEGIN
  IF NEW.group NOT IN ('A', 'B', 'O', 'AB') THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Invalid blood type value, must be one of A, B, O, or AB';
  END IF;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER verify_bloodType_before_update
BEFORE UPDATE
ON bloodtype
FOR EACH ROW
BEGIN
  IF NEW.group NOT IN ('A', 'B', 'O', 'AB') THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Invalid blood type value, must be one of A, B, O, or AB';
  END IF;
END;
//
DELIMITER ;

INSERT INTO donor VALUES(5, "Raymond", "Jackson", 16,5);

UPDATE donor SET donor.age = 16 WHERE donorId = "2";

SELECT * FROM bloodType;