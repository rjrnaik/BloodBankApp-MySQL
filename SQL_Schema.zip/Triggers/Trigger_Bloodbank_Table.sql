USE groupprojectdb;

delimiter //
CREATE TRIGGER before_insert_bloodbank
BEFORE INSERT ON bloodbank
FOR EACH ROW
BEGIN
    IF NEW.name NOT REGEXP '^[^,]+,[^,]+,[^,]+$' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Only CSV format is supported';
    END IF;
END;
//
delimiter ;

SELECT * FROM bloodbank;

INSERT INTO `bloodbank` (`bloodbankId`,`name`,`locationId`,`capacity`) VALUES(1,'Mississauga Blood Bank',10,100);
